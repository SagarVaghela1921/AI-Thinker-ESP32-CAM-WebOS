def tick(bw):
    n = bw.shared.get('count', 0) + 1
    bw.shared['count'] = n
    bw.send('boss', 'count is now %d' % n)
