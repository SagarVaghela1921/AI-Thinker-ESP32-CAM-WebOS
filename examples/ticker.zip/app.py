_bw = None

def start(bw):
    global _bw
    _bw = bw
    bw.shared['ticks'] = 0

def tick(bw):
    bw.shared['ticks'] += 1
    bw.log('ticks.csv', '%s,%d' % (bw.time_text(), bw.shared['ticks']))

def api(params):
    return 'ticks so far: %s' % (_bw.shared.get('ticks') if _bw else 'not running')
