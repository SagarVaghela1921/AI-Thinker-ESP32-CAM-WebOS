import gc

def api(params):
    if params.get('cmd') == 'ping':
        gc.collect()
        return 'pong, free memory: %d bytes' % gc.mem_free()
    return 'unknown command'
