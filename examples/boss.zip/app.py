_bw = None

def start(bw):
    global _bw
    _bw = bw
    bw.shared['count'] = 0
    bw.shared['last'] = ''

def message(bw, sender, text):
    bw.shared['last'] = sender + ': ' + text

def api(params):
    if not _bw:
        return 'not running'
    return 'count=%s\nlast message=%s' % (_bw.shared.get('count'), _bw.shared.get('last'))
